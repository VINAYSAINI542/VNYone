import 'package:flutter/material.dart';

class ChatPage extends StatelessWidget {
  final String name;
  ChatPage({required this.name});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(name), 
        backgroundColor: const Color(0xFF1A237E),
        foregroundColor: Colors.white,
      ),
      body: Column(
        children: [
          // Message Area
          Expanded(
            child: Container(
              color: Colors.grey[100],
              child: Center(
                child: Text(
                  "Starting your conversation with $name\n(VNYone Secure Chat)",
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Colors.grey),
                ),
              ),
            ),
          ),
          
          // Input Field Area
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8.0, vertical: 4.0),
            color: Colors.white,
            child: Row(
              children: [
                IconButton(icon: Icon(Icons.emoji_emotions_outlined), onPressed: () {}),
                Expanded(
                  child: TextField(
                    decoration: InputDecoration(
                      hintText: "Type message...",
                      border: InputBorder.none,
                    ),
                  ),
                ),
                IconButton(icon: Icon(Icons.attach_file), onPressed: () {}),
                IconButton(
                  icon: Icon(Icons.send, color: Color(0xFF1A237E)),
                  onPressed: () {
                    print("Message Sent to $name");
                  },
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
