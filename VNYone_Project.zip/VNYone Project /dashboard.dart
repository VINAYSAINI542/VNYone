import 'package:flutter/material.dart';
import 'chat_page.dart';
import 'create_group.dart';

class VNYoneDashboard extends StatefulWidget {
  @override
  _VNYoneDashboardState createState() => _VNYoneDashboardState();
}

class _VNYoneDashboardState extends State<VNYoneDashboard> with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("VNYone"), // Project Name
        backgroundColor: Color(0xFF1A237E), // Indigo Color
        bottom: TabBar(
          controller: _tabController,
          indicatorColor: Colors.white,
          tabs: [
            Tab(text: "CHATS", icon: Icon(Icons.person)),
            Tab(text: "GROUPS", icon: Icon(Icons.group)),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          _buildList("Personal"),
          _buildList("Groups"),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: Colors.orangeAccent,
        child: Icon(Icons.add),
        onPressed: () {
          // Yahan 'CreateGroupPage' ko 'VNYoneCreateGroup' se check karein agar error aaye
          Navigator.push(context, MaterialPageRoute(builder: (context) => CreateGroupPage()));
        },
      ),
    );
  }

  Widget _buildList(String type) {
    return ListView.builder(
      itemCount: 5,
      itemBuilder: (context, index) {
        String displayName = type == "Groups" ? "Group ${index + 1}" : "Friend ${index + 1}";
        return ListTile(
          leading: CircleAvatar(
            backgroundColor: Color(0xFF1A237E),
            child: Icon(type == "Groups" ? Icons.group : Icons.person, color: Colors.white),
          ),
          title: Text(displayName),
          subtitle: Text("Latest message from $displayName..."),
          onTap: () {
            // Navigator update: ChatPage pass karte waqt
            Navigator.push(context, MaterialPageRoute(
              builder: (context) => ChatPage(name: displayName)
            ));
          },
        );
      },
    );
  }
}
