import 'package:flutter/material.dart';
import 'dashboard.dart';

class VNYoneAuthPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: ElevatedButton(
          child: Text("Login to VNYone"),
          onPressed: () {
            Navigator.push(context, MaterialPageRoute(builder: (context) => VNYoneDashboard()));
          },
        ),
      ),
    );
  }
}

