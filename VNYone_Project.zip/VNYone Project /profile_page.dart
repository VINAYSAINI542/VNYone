import 'package:flutter/material.dart';

class ProfileScreen extends StatelessWidget {
  // ... (Yahan ProfileScreen wala code paste kar dein)
}
